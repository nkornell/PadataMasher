window.onload = function () { 
	//Check the support for the File API support 
	if (window.File && window.FileReader && window.FileList && window.Blob) {
		var fileSelected = document.getElementById('txtfiletoread');
		fileSelected.addEventListener('change', function (e) { 
			//Get the file object 
			var fileTobeRead = fileSelected.files[0];

			readFile(fileTobeRead);

		}, false);
	} 
	else { 
		alert("This software cannot run on your system because you do not have appropriate file API support."); 
	} 
}
