window.onload = function () { 
 //Check the support for the File API support 
 if (window.File && window.FileReader && window.FileList && window.Blob) {
	var fileSelected = document.getElementById('txtfiletoread');
	fileSelected.addEventListener('change', function (e) { 
		 //Set the extension for the file 
		 var fileExtension = /text.*/; 
		 //Get the file object 
		 var fileTobeRead = fileSelected.files[0];
		//Check of the extension match 
		 if (fileTobeRead.type.match(fileExtension)) { 
			 //Initialize the FileReader object to read the 2file 
			 var fileReader = new FileReader(); 
			 fileReader.onload = function (e) { 
				rawFileString = fileReader.result;
		
// 				call other scripts
				computeInputArrays();
				buildTable("input");
// 				computeResults(); // dfd get rid of this when they are allowed to select their own analyses. 
				buildVariableSelectorTable();
				computeResults();

			} 
			fileReader.readAsText(fileTobeRead); 

		 } 
		 else { 
			 alert("Please select a file of filetype text."); 
		 }
 
	}, false);
} 
 else { 
	 alert("This software cannot run on your system because you do not have appropriate file API support."); 
 } 
 }
