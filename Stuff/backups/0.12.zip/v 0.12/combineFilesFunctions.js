var inputArray = [];

// dfd to do: 
// Make the table sortable. 
// make it keep track of unused files and put them in that alert thingy 
// Make it possible to select/unselected multiple checkboxes with one click. 
// deal with column names. maybe get mode for them, too, and use that to identify, count, and remove column names. 
// ---- add a column for number of rows of column names (leave blank unless <> 1)? 

// Additional analyses
// - Maybe make it identify commonalities among rows that are the wrong number of columns and ask about them separately? 
// - Add option to get rid of redundant columns? 
// --- Columns where all values are the same for every participant (vertically)
// --- Columns where all values in one column are the same as all values in another (horizontally) and this is true for all participants??

// Drag and drop works faster than choosing using a button. Figure out why and make them both fast? 

function analyzeCFdata() {
	// Figure out expected values and then color the cells. 
	var numColumns = [];
	var numRows = [];
	var numDeviantRows = [];
	
	// Figure out expected (modal) value for columns, rows, and deviant rows. 
	for (i = 0; i < cfData.length; i++) {
		numColumns.push(cfData[i][1]);
		numRows.push(cfData[i][2]);
		numDeviantRows.push(cfData[i][3]);
	}
	numColumnsMode = Mode(numColumns).value;
	numRowsMode = Mode(numRows).value;
	numDeviantRowsMode = Mode(numDeviantRows).value;

	// Color the cells. 
	for (i = 0; i < cfData.length; i++) {
		document.getElementById('cfTableCell_Row'+i+'_Col'+1).style.backgroundColor = deviationColoration(cfData[i][1], numColumnsMode);
		document.getElementById('cfTableCell_Row'+i+'_Col'+2).style.backgroundColor = deviationColoration(cfData[i][2], numRowsMode);
		document.getElementById('cfTableCell_Row'+i+'_Col'+3).style.backgroundColor = deviationColoration(cfData[i][3], numDeviantRowsMode);
	}
}

function deviationColoration(actual, expected) {
	// Choose a color for each table cell based on how much it deviates from the expected value. 
	var diff = expected - actual;
	increment = 20; // subtract this value for each integer of differene
	colorFloor = 100; // none of the three can go below this value
	if (actual == expected) {
		// white
		return "rgb(255,255,255)";
	} else if (actual < expected) {
		// blue
		red = Math.max(colorFloor, 255 - diff*increment);
		green = Math.max(colorFloor, 255 - diff*increment);
		return "rgb("+red+","+green+",255)";
	} else {
		// red
		blue = Math.max(colorFloor, 255 - Math.abs(diff*increment));
		green = Math.max(colorFloor, 255 - Math.abs(diff*increment));
		return "rgb(255,"+green+","+blue+")";
	}
}


function compute_cfDataForAFile(fileNameString) {
	// This works with a single file's data. 
	// It assumes that inputCell has appropriate values already.
	// It creates cfData (data about the file) and inputArray (the file contents).
	
	// Create inputArray
	inputArray.push(inputCell);
	var fileCounter = inputArray.length - 1; 
	var numRows = inputArray[fileCounter].length;
	
	// if cfData isn't defined, define it. 
	if (cfData[fileCounter] === undefined) { 
		cfData[fileCounter] = []; 
	}

	// Prepare data to compute mode.
	var numColumns = [];
	for (i = 0; i < numRows; i++) {
		numColumns.push(inputArray[fileCounter][i].length);
	}
	
	// Compute mode.
	var mostFrequentNumberOfColumns = Mode(numColumns);

	// put the information that was just computed in cfData
	cfData[fileCounter].push(fileNameString);
	cfData[fileCounter].push(mostFrequentNumberOfColumns.value); // num columns
	cfData[fileCounter].push(numRows); // num rows
	cfData[fileCounter].push(numRows - mostFrequentNumberOfColumns.frequency); // num deviant rows
}

function buildOutputStringCF() {
	// Turn the data into a string that can be stuck in a file for export. 
	var outString = "";
	var f = 0;
	var r = 0;
	
	if (inputArray[0] === undefined) {
		outString += "No Output Data Available";
	} else {
		for (f = 0; f < inputArray.length; f++) {
			if (document.getElementById('cfTableCell_Row'+f+'_Col0').checked == true) {
				for (r = 0; r < inputArray[f].length; r++) {
					outString += inputArray[f][r].join(outputDelimiter) + "\r\n";
				}
			}
		}
	}	
	return outString;
}
