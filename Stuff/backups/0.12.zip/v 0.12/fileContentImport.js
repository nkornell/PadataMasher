var cfData = []; // name, numColumns, numRows, etc. 


function createInputCell() {
	// This function creates inputCell. 
	// inputCell[row][column] is used when there's a single input file. 
	// (Note, it's also used to make inputArray[file][row][column], when there are multiple input files, but that happens elsewhere, sometimes. 


	// Reset inputCell
	inputCell = [];

	// Figure out delimiter
	var first1000characters = rawFileInputString.slice(0, 1000);
	var countCommas = (first1000characters.match(/,/g) || []).length;
	var countTabs = (first1000characters.match(/\t/g) || []).length;
	if (countCommas > countTabs) {
		inputDelimiter = ",";
	} else {
		inputDelimiter = "\t";
	}
	outputDelimiter = inputDelimiter;

	// Split the string into rows
	var inputRow = rawFileInputString.split(/\r\n|\r|\n/g);
	
	// Figure out inputCell[]
	var temp = []; 
	for (i = 0; i < inputRow.length; i++) { 
		temp = inputRow[i].split(inputDelimiter); // Set temp[] = the row of data, split by tabs
		for (k = 0; k < temp.length; k++) {
			temp[k] = temp[k].trim(); // Trim each item in temp
		}
		inputCell.push(temp); // Add temp to inputCell[]
	}
}




function afterAllFilesAreProcessed() {
	if (document.getElementById("checkboxAllowMultiFileImport").checked == false) {
		// if we're just importing one file
		buildTable("input");
		computeResults();
		buildVariableSelectorTable();
	} else {
		buildTableCF();
		analyzeCFdata();
		hideFileSelectorStuff();
		showCFstuff();
	}
}


