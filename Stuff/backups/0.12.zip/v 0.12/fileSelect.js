var allFilesString = "<ol>";
var fileExtension = /text.*/;  //Set the extension for the file 
var listOfFiles;
var arrayOfFiles = [];
var rawFileInputString;

document.getElementById('files').addEventListener('change', handleFileSelect, false); // apparently this... works from the start

// The stuff below pauses after the files are found but before processing them. But apparently finding them is the slow part. 
// document.getElementById('files').addEventListener('change', pauseAbit, false); // apparently this... works from the start
// function pauseAbit(evt) {
// 	setTimeout(function() { handleFileSelect(evt); }, 5000);
// }


function handleFileSelect(evt) {
	/// if they use the button to select a file
	filesSelectedStepOne(evt.target.files);
}

function filesSelectedStepOne (listOfFiles) {
	// hide and show some stuff
	var x = document.getElementById("fileSelectorBox");
	x.style.display = "none";
	x = document.getElementById("processingBox");
	x.style.display = "block";

	// a FileList isn't an array, so move the files into an array.
	for (var i = 0, f; f = listOfFiles[i]; i++) {
		arrayOfFiles.push(f);
	}

	processFiles();
}

// This method is called recursively. The advantage is, getOneFileAtATime can finish processing each file before showing the next one. 
function processFiles() {
    if (arrayOfFiles.length < 1) {
    	afterAllFilesAreProcessed();
    	return;
    }

	var f = arrayOfFiles.shift();
// 	console.log('f.name = ' + f.name);
	
	if (f.type.match(fileExtension)) { 
		getOneFileAtATime(f); 

		allFilesString += '<li>' + f.name;
		document.getElementById("processing").innerHTML = "<p>Processing Files:<p>" + allFilesString + "</p>"; // I wanted this to show the filenames one at a time but if it doesn't might as well move this outside the for loop
	} else {
		allFilesString += '<li><b>Cannot Process: ' + f.name + '</b>';
		processFiles(); // this calls itself recursively. 
	}
}

function getOneFileAtATime(f) {
	var fileReader = new FileReader(); 
	fileReader.readAsText(f);  // I guess this triggers the onload event above

	fileReader.onload = function (e) { 
		rawFileInputString = fileReader.result;		
		createInputCell();

		if (document.getElementById("checkboxAllowMultiFileImport").checked == false) {
			afterAllFilesAreProcessed();
		} else {
			compute_cfDataForAFile(f.name);
			processFiles(); // this calls itself (with a step in between) recursively. 
		}
	}
}






function drop_handler(ev) {
	console.log("Drop");
	event.target.style.backgroundColor = "";
	event.target.style.border = "";
	var files = [];
	
	ev.preventDefault();
	// If dropped items aren't files, reject them
	var dt = ev.dataTransfer;
	if (dt.items) {
// 		Use DataTransferItemList interface to access the file(s)
	for (var i=0; i < dt.items.length; i++) {
	  if (dt.items[i].kind == "file") {
		files.push(dt.items[i].getAsFile());
	  }
	}
	filesSelectedStepOne(files); 
  } else {
  // I've never been able to make this happen and I don't know what it is. 
  console.log("how do you get this to happen??");
	// Use DataTransfer interface to access the file(s)
	for (var i=0; i < dt.files.length; i++) {
	  console.log("... file[" + i + "].name = " + dt.files[i].name);
	}
  }
}

function dragover_handler(ev) {
  console.log("dragOver");
  // Prevent default select and drag behavior
  ev.preventDefault();
}

function dragend_handler(ev) {
  console.log("dragEnd");
  // Remove all of the drag data
  var dt = ev.dataTransfer;
  if (dt.items) {
	// Use DataTransferItemList interface to remove the drag data
	for (var i = 0; i < dt.items.length; i++) {
	  dt.items.remove(i);
	}
  } else {
	// Use DataTransfer interface to remove the drag data
	ev.dataTransfer.clearData();
  }
}

function dragEnter(event) {
// 			document.getElementById("drop_zone").innerHTML = "Entered the dropzone";
		event.target.style.backgroundColor = "#fff"
		event.target.style.border = "dashed #aaa 6px";
}

function dragLeave(event) {
		event.target.style.backgroundColor = "";
		event.target.style.border = "";
}

//       output.push('<li><strong>', escape(f.name), '</strong> (', f.type || 'n/a', ') - ',
//                   f.size, ' bytes, last modified: ',
//                   f.lastModifiedDate ? f.lastModifiedDate.toLocaleDateString() : 'n/a',
//                   '</li>');
//     }
//     document.getElementById('list').innerHTML = '<ul>' + output.join('') + '</ul>';


// ---- old version -----
// window.onload = function () { 
// 	//Check the support for the File API support 
// 	if (window.File && window.FileReader && window.FileList && window.Blob) {
// 		if (document.getElementById("checkboxAllowMultiFileImport").checked == true) {
// 			console.log("true");
// 		} else {
// 			console.log("single");
// 		}
// 
// 		var fileSelected = document.getElementById('files');
// 		fileSelected.addEventListener('change', function (e) { 
// 			//Get the file object 
// 			readFile(fileSelected.files[0]);
// 		}, false);
// 	} 
// 	else { 
// 		alert("This software cannot run on your system because you do not have appropriate file API support."); 
// 	} 
// }
