var inputArray = [];

// dfd to do for combine files: 
// Make it possible to select/unselected multiple checkboxes with one click. Or maybe include the whole row in the label so they're easier to click.
// Make a button to uncheck anything with a warning? 
// Mark or move files that are selected. Or at least spit out a list of which were selected and which weren't. 

// Sorting
// -- Make sort work for the checkbox column. 
// -- Make it sort numerical columns numerically. 
// ----- If it was just sorting CF, I'd say have a parameter for the sort function that tells it whether to do numerical or not. But for all types of sorting, better to have it figure out sort type based on the column contents.)


// Columns to add
// -- Modification date
// -- Warnings 
// -- Num Column names

// Deviant Rows handling
// -- make an option to mark deviant rows with an initial column in output. 
// this way we don't have to create separate files, and they can easily find and exclude that stuff or put it back in. 
// - Maybe make it identify commonalities among rows that are the wrong number of columns and ask about them separately? 

// deal with column names. maybe get mode for them, too, and use that to identify, count, and remove column names. 
// ---- add a column for number of rows of column names (leave blank unless <> 1)? 

// Redundant columns
// - Add option to get rid of redundant columns? 
// --- Columns where all values are the same for every participant (vertically)
// --- Columns where all values in one column are the same as all values in another (horizontally) and this is true for all participants??

// Redundant rows
// -- Make it so you can identify a column where, if the same thing appears in consecutive rows, if flags the row.  
// -- Put it in the warnings column as "repeated row"
// Drag and drop works faster than choosing using a button. Figure out why and make them both fast? 




function compute_cfDataForAFile(fileNameString) {
	// This works with a single file's data. 
	// It assumes that appropriate values are already assigned to inputCell.
	// It creates cfData (data about the file) and inputArray (the file contents).
	
	// Create inputArray
	inputArray.push(inputCell);
	var fileCounter = inputArray.length - 1; 
	var numRows = inputArray[fileCounter].length;
	
	// if cfData isn't defined, define it. 
	if (cfData[fileCounter] === undefined) { 
		cfData[fileCounter] = []; 
	}

	// Prepare data to compute mode.
	var numColumns = [];
	for (i = 0; i < numRows; i++) {
		numColumns.push(inputArray[fileCounter][i].length);
	}
	
	// Compute mode.
	var mostFrequentNumberOfColumns = Mode(numColumns);

	// put the information that was just computed in cfData
	cfData[fileCounter].push(fileNameString);
	cfData[fileCounter].push(mostFrequentNumberOfColumns.value); // num columns
	cfData[fileCounter].push(numRows); // num rows
	cfData[fileCounter].push(numRows - mostFrequentNumberOfColumns.frequency); // num deviant rows
// 	cfData[fileCounter].push(inputArray[fileCounter][0].join(fileDelimiterArray)); // first row of data (i.e., column names)
// 	cfData[fileCounter].push(inputFileDelimiter); 
	fileColumnNamesArray.push(inputArray[fileCounter][0]);
}

function analyzeCFexpectedvalues() {
	// Figure out expected values and then color the cells. 
	var numColumns = [];
	var numRows = [];
	var numDeviantRows = [];
	var colNamesString = [];
	
	// Figure out expected (modal) value for columns, rows, and deviant rows. 
	for (i = 0; i < cfData.length; i++) {
		numColumns.push(cfData[i][1]);
		numRows.push(cfData[i][2]);
		numDeviantRows.push(cfData[i][3]);
	}
	
	var numColumnsMode = Mode(numColumns).value;
	var numRowsMode = Mode(numRows).value;
	var numDeviantRowsMode = Mode(numDeviantRows).value;
	modalDelimiter = Mode(fileDelimiterArray).value;
	
	for (i = 0; i < fileColumnNamesArray.length; i++) {
		colNamesString.push(fileColumnNamesArray[i].join(modalDelimiter));
	}
	modalColumnNameString = Mode(colNamesString).value;

	// Color the cells. 
	for (i = 0; i < cfData.length; i++) {
		document.getElementById('cfTableCell_Row'+i+'_Col'+1).style.backgroundColor = deviationColoration(cfData[i][1], numColumnsMode);
		document.getElementById('cfTableCell_Row'+i+'_Col'+2).style.backgroundColor = deviationColoration(cfData[i][2], numRowsMode);
		document.getElementById('cfTableCell_Row'+i+'_Col'+3).style.backgroundColor = deviationColoration(cfData[i][3], numDeviantRowsMode);
	}
}

function buildTableCF() {
	var out = "";

	// Build Header
	out = "<tr><th onclick='sortTable(0, "+'"cfTable"'+")' title='Click to Sort'>Use in output</th>";
	out += "<th onclick='sortTable(1, "+'"cfTable"'+")' title='Click to Sort'>File name</th>";
	out += "<th onclick='sortTable(2, "+'"cfTable"'+")' title='Click to Sort'>Columns</th>";
	out += "<th onclick='sortTable(3, "+'"cfTable"'+")' title='Click to Sort'>Rows</th>";
	out += "<th onclick='sortTable(4, "+'"cfTable"'+")' title='Click to Sort'>Deviant rows</th></tr>";

	// Build all the other cells.
	for (i = 0; i < cfData.length; i++) {
		out = out + "<tr>";
		out = out + '<td><label><input type="checkbox" id="cfTableCell_Row'+i+'_Col0" checked ></label></td>';
		for (k = 0; k < cfData[i].length ; k++) {
			out = out + '<td id=cfTableCell_Row'+i+'_Col'+k+'>' + cfData[i][k] + "</td>";
		}
		out = out + "</tr>";
	}
	
	// Put everything in the HTML.
	document.getElementById("cfTable").innerHTML = "<table>" + out + "</table>";
	
	// If necessary, add an alert for excluded files. 
	if (excludedFile_name.length > 0) {
		var x = document.getElementById("cfExcludedFilesBox");
		x.style.display = "block";
// 		x = document.getElementById("cfExcludedFilesButton");
// 		x.style.display = "inline-block";		
		document.getElementById("cfExcludedFilesText").innerHTML = excludedFile_name.join('<br>');
	}
}



function deviationColoration(actual, expected) {
	// Choose a color for each table cell based on how much it deviates from the expected value. 
	var diff = expected - actual;
	increment = 20; // subtract this value for each integer of differene
	colorFloor = 100; // none of the three can go below this value
	if (actual == expected) {
		// white
		return "rgb(255,255,255)";
	} else if (actual < expected) {
		// blue
		red = Math.max(colorFloor, 255 - diff*increment);
		green = Math.max(colorFloor, 255 - diff*increment);
		return "rgb("+red+","+green+",255)";
	} else {
		// red
		blue = Math.max(colorFloor, 255 - Math.abs(diff*increment));
		green = Math.max(colorFloor, 255 - Math.abs(diff*increment));
		return "rgb(255,"+green+","+blue+")";
	}
}


function buildOutputStringCF() {
	// Turn the data into a string that can be stuck in a file for export. 
	// It uses the modal delimiter as the output delimiter for all rows.
	// It starts with the modal column names and excludes any other instances of those column names. 
	var outString = "";
	var f = 0;
	var r = 0;
	var temp = "";
	
	if (inputArray[0] === undefined) {
		outString = "No Output Data Available";
	} else {
		outString = modalColumnNameString + "\r\n"; // start with column names
		for (f = 0; f < inputArray.length; f++) { // for every file...
			if (document.getElementById('cfTableCell_Row'+f+'_Col0').checked == true) { // if its checkbox is checked...
				for (r = 0; r < inputArray[f].length; r++) { // go through all of its rows...
					temp = inputArray[f][r].join(modalDelimiter); // join the row array into a string
					if (temp != modalColumnNameString) { // if the string isn't the column names...
						outString += temp + "\r\n"; // add it to outString. 
					}
				}
			}
		}
	}	
	return outString;
}
