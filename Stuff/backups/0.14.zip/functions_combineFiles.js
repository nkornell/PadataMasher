
// to do for combine files: 
// Make it possible to select/unselected multiple checkboxes with one click. Or maybe include the whole row in the label so they're easier to click.
// Make an option to remove unchecked files and recalculate modal values.
// Show a log that can be copied or allow the user to export a list of whether files were included or excluded. 

// Sorting
// -- Make sort work for the checkbox column. 

// Press 'remove' next to a file to get it out of the whole coloration thing and everything?

// Moving files around
// -- remname the file at that point as well (if possible).
// -- I don't think it's possible(?) but it is possible to create a new file. So I could create new versions of all the good ones...
// -- see: https://stackoverflow.com/questions/30733904/renaming-a-file-object-in-javascript
// -- const myNewFile = new File([myFile], 'new_name.png', {type: myFile.type});

// 
// Assign a "type" to each column, based on non-deviant rows, and check whether each row deviates.
// -- based on whether it's numeric, whether it repeats never, sometimes, or always, etc. 

// Within a file, identify columns that 
// -- Make it so you can identify a column where, if the same thing appears in consecutive rows, if flags the row.  

// Preview
// Put in a preview button so they can decide whether or not to exclude the file without having to go open it. 
// -- Maybe show it, hopefully with problems highlighted. 
// -- or maybe just launch it for them in their default app

// Deviant Rows handling
// - Maybe make it identify commonalities among rows that are the wrong number of columns and ask about them separately? 

// Settings
// -- make it possible to ignore (i.e., not count as problems): column names, numrows, etc.
// ---- this will mean it'll need to be able to recalculate whenever. 
// ---- it'll also need to count up the points at the end, not ongoing-ly, probably. especially for stuff that happens within a single file

// Redundant columns
// - Add option to get rid of redundant columns? 
// --- Columns where all values are the same for every participant (vertically)
// --- Columns where all values in one column are the same as all values in another (horizontally) and this is true for all participants??

//// organize messages so they're easier to read, and prioritized. maybe they should all be done in computescores or whatever?

// Drag and drop works faster than choosing using a button. Figure out why and make them both fast? 
// -- Also, drag and drop is slow with a large # of files. 
// ---- Make the outline dashed without having to wiggle the mouse? 
// ---- Or make it so it doesn't matter where a file is dropped, it's treated like a drag and drop? 


var inputArray = [];
var lastColumn = [];
var cfData = []; // this is information about the file that will go in the cf table: fileName, numColumns, numRows, etc. 
var numColumnsMode = 0;
var numRowsMode = 0;
var finalTrialNumMode = 0;
var modalColumnNameString = "";
var modalDelimiter = '';
var modalProblemCount = 0;
// var fileLastRowArray = [];
// var fileColumnNamesArray = [];
// var message = [];

function compute_cfDataForAFile(fileNameString) {
	// This works with a single file's data. 
	// It assumes that appropriate values are already assigned to inputCell.
	// It creates cfData (data about the file) and inputArray (the file contents).
	
	// Create inputArray
	inputArray.push(inputCell);
	var fileCounter = inputArray.length - 1; 
	var numRows = inputArray[fileCounter].length;
	var tempHighestRowNumWithColumnNames = 0;
	var lastPlus1equalsThis_columnNum = [];
	var constantColumn_value = [];
	var tempMessage = "";	
	var temp_arrayMadeFromOneColumn = [];

	// Go through all of the rows. 
	var tempNumColumns = [];
	for (i = 0; i < numRows; i++) {
		// Prepare data to compute modal number of columns for this file. 
		tempNumColumns.push(inputArray[fileCounter][i].length); 

		// Find repeats of columnNames.
		if (inputArray[fileCounter][i].toString() == inputArray[fileCounter][0].toString() && i > 0) { // if it's the column names again
			tempHighestRowNumWithColumnNames = i;
		}
		
		// Find columns that contains trial numbers or that remain constant throughout.
		for (j = 0; j < inputArray[fileCounter][i].length; j++) {
			if (i < 2 || inputArray[fileCounter][i-1][j] === undefined) {
				// do nothin'
			} else if (inputArray[fileCounter][i][j] - 1 == inputArray[fileCounter][i-1][j]) { // this value is 1 more than the previous row's value
				// add every column name that fits to an array.
				lastPlus1equalsThis_columnNum.push(j);
			}
		}
	}
		
	
	// Compute modal number of columns.
	var mostFrequentNumberOfColumns = Mode(tempNumColumns);
	var maxNumberOfColumns = Math.max.apply(Math, tempNumColumns);
	
	// -- Identify any plusOneColumn (i.e., trial numbers that increment by 1 each time) --
	var tempPlusOneColumn = -1;
	var possiblePlus1column = Mode(lastPlus1equalsThis_columnNum);
	var tempFinalTrialNum = 0;
	if (possiblePlus1column.frequency/numRows > .4) { // the proportion here is just a gut feeling
		// if there is, record the column number. 
		tempPlusOneColumn = possiblePlus1column.value;
	}
	
	// -- Identify any constant columns you can find. -- 
	// create a separate array made up of each column of the input 
	for (j = 0; j < mostFrequentNumberOfColumns.value; j++) { // j is the column we're on, i is the row
		for (i = 1; i < numRows; i++) { //  starting with 1 
			if (temp_arrayMadeFromOneColumn[j] === undefined) {temp_arrayMadeFromOneColumn[j] = [];} 
			if (inputArray[fileCounter][i][j] != undefined) {
				temp_arrayMadeFromOneColumn[j].push(inputArray[fileCounter][i][j]); // make an array for each column
			}
		}
	}
	// look for constant columns in each of the arrays of columns
	for (j = 0; j < mostFrequentNumberOfColumns.value; j++) { 
		temp_mode = Mode(temp_arrayMadeFromOneColumn[j]);
		if (temp_mode.frequency/numRows > .8) { // if the same value appears in this proportion of trials... (gut feeling)
			// assign the modal value to constantColumn_value for that column. you can tell whether a column is constant by seeing whether it has a value or remains undefined.
			constantColumn_value[j] = temp_mode.value; 
		}
	}

	
	// dfd to do next
	// ding rows that don't have the expected value in a constant column


	// -- figure out problems -- //
	var previousTrialNum = -999;
	var gap = 0;
	var problemCount = 0;
	var hasTrialNum = false;
	var thisTrialNum = 0;
	
	if (lastColumn[fileCounter] === undefined) { 
		lastColumn[fileCounter] = []; 
	}
	
	lastColumn[fileCounter].push('problem with file: no column names at the top of this file'); // this only appears if the 1st row isn't column names. I initially added it because without it lastColumn will be out of synch when it pushes because the loop below starts at 1.
	for (i = 1; i < numRows; i++) { //  starting with 1
		additionalColumnText = '';
		hasTrialNum = false; // until we find it
		thisTrialNum = -999;
		
		// figure out this trial's trial number
		if (tempPlusOneColumn != -1) { // if there is a plus one column (ie trial numbers)
			if (Number.isInteger(Number(inputArray[fileCounter][i][tempPlusOneColumn]))) { // if the number value of it is an integer
				hasTrialNum = true;
				thisTrialNum = inputArray[fileCounter][i][tempPlusOneColumn];
				tempFinalTrialNum = thisTrialNum;
			}
		}
		
		// figure out gap between last trial number and this one
		if (hasTrialNum && (previousTrialNum != -999)) {
			gap = thisTrialNum - previousTrialNum;
		} else { 
			gap = -999;
		}
		
		if (i <= tempHighestRowNumWithColumnNames) { // if it comes before future column names
			if (i < tempHighestRowNumWithColumnNames) {
				additionalColumnText = 'problem with row: column names appear later in this file';
				problemCount++;
			} else {
				additionalColumnText = 'ok, column names'; // this won't show up because column names aren't shown. 
				previousTrialNum = -999;
				// note I don't add to problem count here because it's not a problem itself... only if it makes actual rows repeat
			}
		} else if (mostFrequentNumberOfColumns.value != inputArray[fileCounter][i].length) { // if it's the wrong num of columns
			problemCount++;
			additionalColumnText = 'problem with row: number of columns = ' + inputArray[fileCounter][i].length + ' (' + mostFrequentNumberOfColumns.value + ' expected)';
		} else if (hasTrialNum == false) { // if there's no trial number here
			problemCount++;
			additionalColumnText = 'problem with row: trial number not found';
			if (tempPlusOneColumn == -1) {
				additionalColumnText = 'problem with file: trial numbers not found in this file';
			}
		} else if (previousTrialNum == -999) { // if it's the first trial num that we've found
			additionalColumnText = 'ok'; // first row
		} else if (gap != -999) { // it has a trial num and a gap was computed
			if (gap == 1) {
				additionalColumnText = 'ok';
			} else if (previousTrialNum == -999) {
				additionalColumnText = 'ok';
			} else if (gap == 0) {
				problemCount++;
				additionalColumnText = 'problem with row: trial number same as previous';
			} else if (gap > 1) {
				problemCount += gap-1;
				additionalColumnText = 'warning: trial num increased by ' + gap;
			} else if (gap < 0) {
				problemCount += Math.abs(gap)+1;
				additionalColumnText = 'warning: trial num decreased by ' + Math.abs(gap);
			}
		} else { // can't compute gap 
			problemCount++;
			additionalColumnText = "warning: if this happened, there is an error in compute_cfDataForAFile";
		}

		if (hasTrialNum) {
			previousTrialNum = inputArray[fileCounter][i][tempPlusOneColumn];
		}
		
		

		
		// if a message should be added to the row, add it
		if (additionalColumnText != 'ok') {
			additionalColumnText = additionalColumnText;
		}
		lastColumn[fileCounter].push(additionalColumnText);
 	}

	
	// if cfData isn't defined, define it. 
	if (cfData[fileCounter] === undefined) { 
		cfData[fileCounter] = []; 
	}

	// put the information that was just computed in cfData
	cfData[fileCounter] = {
		fileName: fileNameString,
		numColumns: mostFrequentNumberOfColumns.value,
		maxNumberOfColumns: maxNumberOfColumns,
		numRows: numRows,
// 		numDeviantRows: numRows - mostFrequentNumberOfColumns.frequency, // num deviant rows
		numlastRowDeviations: 0,
		numProblemsWithinFile: problemCount,
		numProblemsTotal: 0, // this is problems within file plus problems compared to other files. To get the latter, subtract. 
		columnNames: [],
		lastRow: [],
		message: tempMessage,
		plusOneColumn: tempPlusOneColumn,
		finalTrialNum: tempFinalTrialNum,
		largestRowNumWithColumnNames: tempHighestRowNumWithColumnNames,
		constantColumn_value: constantColumn_value,
	};
	
	cfData[fileCounter].columnNames = inputArray[fileCounter][0]; // for this line and the next two there has to be a better way to initialize (above). But who cares I guess. 
	cfData[fileCounter].lastRow= inputArray[fileCounter][numRows-1];
}

function analyzeCFexpectedvalues() {
	// Figure out expected values and then color the cells. 
	var numColumns = [];
	var numRows = [];
	var finalTrialNum = [];
	var colNamesString = [];
	var numProblems = [];
// 	var numDeviantRows = [];
	var perfectLastRowArray = [];
	var plraLength = [];  //perfectLastRowArray length
	var plrCol = [];
	var plrSignature = [];
	var plrSignatureCount = 0;
	var score = 0;
	var tempMessage = "";
		
	modalDelimiter = Mode(fileDelimiterArray).value;

	// Figure out expected (modal) value for some variables. 
	for (i = 0; i < cfData.length; i++) {
		// put all the values of the variable into an array that can be run through the Mode function. 
		numColumns.push(cfData[i].numColumns);
		numRows.push(cfData[i].numRows);
		finalTrialNum.push(cfData[i].finalTrialNum);
		colNamesString.push(cfData[i].columnNames.join(modalDelimiter));
		numProblems.push(cfData[i].numProblemsWithinFile);
// 		numDeviantRows.push(cfData[i].numDeviantRows);
	}
	numColumnsMode = Mode(numColumns).value;
	numRowsMode = Mode(numRows).value; 	// maybe make it only care about numRows if mode frequency is > .5?
	finalTrialNumMode = Mode(finalTrialNum).value;
	modalColumnNameString = Mode(colNamesString).value;
	modalProblemCount = Mode(numProblems).value; // number of problems within perfect files
// 	numDeviantRowsMode = Mode(numDeviantRows).value;

	

	// figure out features of the last row in the 'perfect' files
	for (i = 0; i < cfData.length; i++) {
		// maybe add finaltrialnum or finaltrialnum or numproblems to perfection checker (i.e., to the if below
		if (cfData[i].numRows == numRowsMode && cfData[i].columnNames.join(modalDelimiter) == modalColumnNameString) { // if it looks like a perfect file
			perfectLastRowArray.push(cfData[i].lastRow); // an array containing what the last row should look like
			plraLength.push(cfData[i].lastRow.length); // number of columns in those perfect-looking last rows
		}
	}
	plraLengthMode = Mode(plraLength).value; // modal number of columns in the perfect-looking last rows
	
	// -- start processing the last row --	
	// Create a 2d array (plrCol), extracted from the perfect last rows, that contains every entry in each column 
 	for (i = 0; i < perfectLastRowArray.length; i++) {
 		if (perfectLastRowArray[i].length == plraLengthMode) {
			for (col = 0; col < perfectLastRowArray[i].length; col++) {
				if (plrCol[col] === undefined) { 
					plrCol[col] = []; 
				}
				plrCol[col].push(perfectLastRowArray[i][col]);
			}		
		}
	}
	
	// Find signature column values in the perfect last rows, (signature values appear 100% of the time in perfect last rows). 
	for (col = 0; col < plrCol.length; col++) {
		if (Mode(plrCol[col]).frequency == plrCol[col].length) { // if the modal value appears 100% of the time
			plrSignature.push(Mode(plrCol[col]).value);
			plrSignatureCount++;
		} else {
			plrSignature.push('not a signature column');
		}
	}
	// at some point, make this (above) a separate function and use it on stepouts maybe?

	
	// Figure out how well the last row matches the signature columns. 
	for (i = 0; i < cfData.length; i++) {
		score = 0;
		tempMessage = "";
		for (col = 0; col < plrSignature.length; col++) {
			if (plrSignature[col] != 'not a signature column') {
				if (cfData[i].lastRow[col] != undefined) {
					if (cfData[i].lastRow[col] == plrSignature[col]) {
						score++;
					} else {
						tempMessage += 'In the final row, expected ' + plrSignature[col] + ', found ' + cfData[i].lastRow[col] + '; ';
					}
				}
			}
		}
		cfData[i].numlastRowDeviations = plrSignatureCount - score;
		if (cfData[i].numlastRowDeviations > 2) {
			tempMessage = "Final row not found (" + (plrSignatureCount - score) + " deviations); ";
		}
		cfData[i].message += tempMessage;
	}
	
	
	// examine constant columns, identify the one(s) that are constant for everybody
	// first see how many files a given column is constant in
	var temp_constantInEveryFileCounter = [];

	for (i = 0; i < numColumnsMode; i++) {
		temp_constantInEveryFileCounter[i] = 0;
		for (j = 0; j < cfData.length; j++) {
			if (cfData[j].constantColumn_value[i] != undefined) {
				temp_constantInEveryFileCounter[i]++;
			}
		}
	}
	// then decide, for each column, whether it should be considered a constant column. 
	constantInEveryFile_columnNum = [];
	for (i = 0; i < numColumnsMode; i++) {
		if (temp_constantInEveryFileCounter[i] / cfData.length > .6) { // gut feeling
			constantInEveryFile_columnNum.push(i);
		}
	}
	// then figure out modal value for and frequency for each constant column and decide whether repeatsAcrossFiles, uniqueAcrossFiles, or neither.
	var temp_constantColumn_value = []; 
	for (j = 0; j < constantInEveryFile_columnNum.length; j++) {
		temp_constantColumn_value = [];
		for (i = 0; i < cfData.length; i++) {
			temp_constantColumn_value.push(cfData[i].constantColumn_value[j]);
		}
		temp_mode = Mode(temp_constantColumn_value);
		if (temp_mode.frequency / cfData.length < .3) { // if most (hopefully all) files have their own unique value in this constant column 
			console.log( 'uniqueAcrossFiles: ' + j);
		} else if (temp_mode.frequency / cfData.length > .7) { // if most (or hopefully all) values in this constant column are the same
			console.log('repeatsAcrossFiles: ' + j + ' ' + temp_mode.value);
		} else {
			console.log("no man's land across files: " + j + ' ' + temp_mode.value);
		}
	} 
	
	// dfd to do next: 
	// Make a variable that keeps track of the 'type' of each column;
	// - constant repeating
	// - constant unique
	// - trial numbers
	// Ding files (in computeNumProblemsComparedToOtherFiles) that aren't the right type in that column	
	
}


function computeNumProblemsComparedToOtherFiles() {
	// Figure out how many problems there are in the file overall. 
	var probCount = 0;
	var numRowsDeviation = 0;
	
	for (i = 0; i < cfData.length; i++) {
		probCount = 0;


		if (cfData[i].plusOneColumn == -1) { 
			// if trial numbers weren't found compute problems based on num rows
			numRowsDeviation = cfData[i].numRows - numRowsMode; // num rows based on counting rows
			probCount += Math.abs(numRowsDeviation);
		} else {
			// if trial numbers were found, compute problems based on final trial number
			// note this is preferable because unlike rownum, it's not redundant with problems noticed within the file
			numRowsDeviation = cfData[i].finalTrialNum - finalTrialNumMode;
			probCount += Math.abs(numRowsDeviation);
// console.log( cfData[i].fileName + ' '+ Math.abs(numRowsDeviation));

		}
		
// 		probCount += Math.abs(cfData[i].numDeviantRows - numDeviantRowsMode);  // this is computed within file, so get rid of it
		probCount += Math.abs(cfData[i].numlastRowDeviations);

		// check the column names
		if (cfData[i].columnNames.join(modalDelimiter) != modalColumnNameString) {
			if (cfData[i].numColumns != numColumnsMode) {
				probCount += 10; // either add 10 if the number of column names is wrong
				cfData[i].message += 'Columns of data: ' + cfData[i].numColumns + ' ('+ numColumnsMode + ' expected); ';
			} else {
				probCount += 5; // or add 5 if the column names mismatch but num columns is correct
				cfData[i].message += "Column names mismatch other files; ";
			}
		}
		
		if (numRowsDeviation > 0) {
			cfData[i].message += Math.abs(numRowsDeviation) + ' more trials than expected; ';
		} else if (numRowsDeviation < 0) {
			cfData[i].message += Math.abs(numRowsDeviation) + ' fewer trials than expected; ';
		}
		
		if (cfData[i].largestRowNumWithColumnNames > 0) {
			cfData[i].message += "Column names appear in row " + (cfData[i].largestRowNumWithColumnNames + 1) + "; ";
		}

		cfData[i].numProblemsTotal = probCount + cfData[i].numProblemsWithinFile - modalProblemCount;
	}

// note: the stuff below worked, but I decided not to use it. 
// it figured out which deviated more from expectations, numrows or finaltrialnum, and reported that. 
// but then I realized: anything that makes them diverge will be captured within the file (skipped rows etc)
// so using this would just end up double-counting stuff. 
// 		// figure out what to report for number of rows deviation
// 		var numRowsDeviation = cfData[i].numRows - numRowsMode; // num rows based on counting rows
// 		var finalTrialNumDeviation = cfData[i].finalTrialNum - finalTrialNumMode; // num rows based on last trial num	
// 		console.log( cfData[i].fileName);
// 		console.log( 'cfData[i].finalTrialNum='+cfData[i].finalTrialNum);
// 		console.log( 'numRowsDeviation='+numRowsDeviation+' finalTrialNumDeviation='+finalTrialNumDeviation);
// 		if (cfData[i].finalTrialNum = 0) { // if a final trial number was not found
// 			rowNumProblemsTotal = numRowsDeviation; // use row count
// 		} else if (numRowsDeviation * finalTrialNumDeviation < 0) { // if the two deviations have different signs (multiply and find a negative) 
// 			rowNumProblemsTotal = Math.abs(finalTrialNumDeviation) + Math.abs(numRowsDeviation); // get their summed absolute value
// 			if (numRowsDeviation + finalTrialNumDeviation < 0) { // if the larger is negative
// 				rowNumProblemsTotal = -1*rowNumProblemsTotal; // make the deviation negative
// 			}
// 		} else if (Math.abs(finalTrialNumDeviation) > Math.abs(numRowsDeviation)) { // if the bigger deviation is trial number
// 			rowNumProblemsTotal = finalTrialNumDeviation;
// 		} else { // otherwise use row count
// 			rowNumProblemsTotal = numRowsDeviation;
// 		}
// 		console.log( 'rowNumProblemsTotal='+rowNumProblemsTotal);
}
	


function buildTableCF() {
	var out = "";
	
	document.getElementById('cfHeading').innerHTML = 'File information (' + cfData.length + ' files)';

	// Build Header
	out = "<tr><th onclick='sortTable(0, "+'"cfTable"'+")' title='Click to Sort'>Use in output</th>";
	out += "<th onclick='sortTable(1, "+'"cfTable"'+")' title='Click to Sort'>File name</th>";
	out += "<th onclick='sortTable(2, "+'"cfTable"'+")' title='Click to Sort'>Rows</th>";
	out += "<th onclick='sortTable(3, "+'"cfTable"'+")' title='Click to Sort'>Problems</th>";
	out += "<th onclick='sortTable(4, "+'"cfTable"'+")' title='Click to Sort'>Message</th></tr>";

	// Build all the other cells.
	for (i = 0; i < cfData.length; i++) {
		// First figure out, based on number of problems, whether the row is good, warning, or bad
		if (cfData[i].numProblemsTotal <= 5) {
			tdText = '<td class=cfTableCell_Row_good>';
		} else if (cfData[i].numProblemsTotal <= 20) {
			tdText = '<td class=cfTableCell_Row_warning>';
		} else {
			tdText = '<td class=cfTableCell_Row_bad>';
		}
		// write them.
		out = out + "<tr>";
		out = out + tdText + '<label><input type="checkbox" id="cfTableCell_Row'+i+'_Col0" checked ></label></td>';
		out = out + tdText + cfData[i].fileName + "</td>";
		out = out + tdText + cfData[i].numRows + "</td>";
		out = out + tdText + cfData[i].numProblemsTotal + "</td>";
		out = out + tdText + cfData[i].message + "</td>";
		out = out + "</tr>";
	}
	
	// Put everything in the HTML.
	document.getElementById("cfTable").innerHTML = "<table>" + out + "</table>";
	
	// If necessary, add an alert for excluded files. 
	if (excludedFile_name.length > 0) {
		var x = document.getElementById("cfExcludedFilesBox");
		x.style.display = "block";
		document.getElementById("cfExcludedFilesText").innerHTML = excludedFile_name.join('<br>');
	}
	
}

function adjustCheckboxes() {
	// uncheck columns that look questionable. 
	for (i = 0; i < cfData.length; i++) {
		if (cfData[i].numProblemsTotal > 5) {
// 			document.getElementById('cfTableCell_Row'+i+'_Col0').checked = false; // dfd put back
		}
	}
}



function buildOutputStringCF() {
	// Turn the data into a string that can be stuck in a file for export. 
	// It uses the modal delimiter as the output delimiter for all rows.
	// It starts with the modal column names and excludes any other instances of those column names. 
	var outString = "";
	var f = 0;
	var r = 0;
	var temp = "";
	var tempExtraDelimiters = "";
	var extraDelimitersNeeded = 0
	
	if (inputArray[0] === undefined) {
		return "No Output Data Available";
	}
	

	
	outString = modalColumnNameString + modalDelimiter + "Data cleanup notes" + "\r\n"; // start by writing the column names
	
	for (f = 0; f < inputArray.length; f++) { // for every file...
		if (document.getElementById('cfTableCell_Row'+f+'_Col0').checked == true) { // if its checkbox is checked...
			for (r = 0; r < inputArray[f].length; r++) { // go through all of its rows...
				temp = inputArray[f][r].join(modalDelimiter); // join the row array into a string
				extraDelimitersNeeded = Math.max( (modalColumnNameString.split(modalDelimiter).length), cfData[f].maxNumberOfColumns  );
				extraDelimitersNeeded = extraDelimitersNeeded - inputArray[f][r].length;					
				tempExtraDelimiters = Array(extraDelimitersNeeded+1).join(modalDelimiter);
				
				if (temp != modalColumnNameString) { // if the string isn't the column names...
					outString += temp + tempExtraDelimiters + modalDelimiter + lastColumn[f][r] + "\r\n"; // add it to outString. 
				} else { 
					console.log("wut"); 
				}
			}
		}
	}	
	return outString;
}

// function deviationColoration(val) {
// // I now use css, so this is obsolete
// 
// 
// 	// Choose a color for each table cell based on how much it deviates from the expected value. 
// 	increment = 20; // subtract this value for each integer of difference
// 	colorFloor = 100; // none of the three can go below this value
// 	if (val == 0) {
// 		// white
// 		return "rgb(255,255,255)";
// 	} else if (val > 0) {
// 		// blue
// 		red = Math.max(colorFloor, 255 - val*increment);
// 		green = Math.max(colorFloor, 255 - val*increment);
// 		return "rgb("+red+","+green+",255)";
// 	} else {
// 		// red
// 		blue = Math.max(colorFloor, 255 - Math.abs(val*increment));
// 		green = Math.max(colorFloor, 255 - Math.abs(val*increment));
// 		return "rgb(255,"+green+","+blue+")";
// 	}
// }