// ---------- Set variables ---------- //
var inputCell = [];
var outputCell = [];
var allBetweenLevelValues = [];
var betweenColumnsSelected = [];
var allWithinLevelValues = [];
var withinColumnsSelected = [];
var dependentVariableColumnsSelected = [];
var howEachVariableIsUsed = [];
var toolTipContent = [];
var numLevels = [];
var setsOfValues = [];
var fileDelimiterArray = [];


window.addEventListener("keydown", checkKeyPressed, false); // make the window listen for a key press	


// 	window.ondrop=(drop_handler(event));
// ondrop="drop_handler(event);" ondragover="dragover_handler(event);" ondragend="dragend_handler(event);" ondragenter="dragEnter(event)" ondragleave="dragLeave(event)"

function checkKeyPressed(e) {
	if (e.keyCode == "79" && fileDelimiterArray.length == 0) { // if they pressed 'o' or 'O', and haven't already input data...
		document.getElementById("files").click(); // Simulate a button press 
	}
}	


function convertTabsToArrayMembers(inArray, inString) {
	var i = 0;
	var x = [];
	x = inString.split("\t");
	for (i = 0; i < x.length; i++) {
		inArray.push(x[i]);
	}
}

function buildTable(typ) {
	var out = "";
	if (typ == "input") {
		var tempCell = inputCell;
		var alertElementName = "inputAlerts";
		var tableID = "inputTable";
		console.log( 'inputTable'); 

	} else {
		var tempCell = outputCell;
		var alertElementName = "resultAlerts";
		var tableID = "outputTable";
		console.log( 'outputTable'); 
	}
	
	if (tempCell[0] === undefined) { // I don't think this ever happens, but just in case
		out = "nothing here";
		console.log("nothing here");
	} else if (tempCell[0].join() == "") { // no columns have been selected
		out = "<div style='height: 200px; display: flex; align-items: center; justify-content: center; text-align:center; font-size: 150%; font-weight: bold; color: #aaa '>Start adding variables<br>and analyses</div>";
	} else {
		// Build Header
		out = "<tr>";
		for (i = 0; i < tempCell[0].length; i++) {
			out += "<th onclick='sortTable("+i+", "+'"'+tableID+'"'+")' title='Click to Sort'><div id='" + typ + "," + tempCell[0][i] + "'>" + tempCell[0][i] + "</div></th>";
		}

		out = out + "</tr>";
		out = out.replace(/no\twithin\tlevels/g,"");

		// Figure out how many rows to show.
		var maxRowsToShow = 200;
		var rowsToShow = Math.min(maxRowsToShow, tempCell.length);
					
		if (tempCell.length > maxRowsToShow) {
			var alertToShow = "Showing first " + maxRowsToShow + " rows (of " + tempCell.length + ").";
			document.getElementById(alertElementName).innerHTML = alertToShow;
			var x = document.getElementById(alertElementName);
			x.style.display = "inline-block";
		} else {
			var x = document.getElementById(alertElementName);
			x.style.display = "none";
		}

		// Build Data
		for (i = 1; i < rowsToShow; i++) {
			out = out + "<tr>";
			for (k = 0; k < tempCell[i].length; k++) {
				if (tempCell[i][k] === undefined) {
					out = out + "<td></td>";
					console.log("This happened!!!!!!!!!!! Programer person, you need to take a peek.");
					tempCell[i][k] = ""; // not sure this happens but if it does I need to fix it by setting the variable to "" (but note this is the temp version, not the real variable)
				} else {				
					out = out + "<td>" + tempCell[i][k] + "</td>";
				}
			}
			out = out + "</tr>";
		}
	}
	
	// Show the table
	document.getElementById(tableID).innerHTML = "<table>" + out + "</table>";
}


function exportOutput() {
	var element = document.createElement('a');
	if (analysisType == "compute") {
		// create output for MC
		element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(buildOutputStringMC()));
		element.setAttribute('download', "Pivoted Output");
	} else {
		// create output for CF
		element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(buildOutputStringCF()));
		element.setAttribute('download', "Combined Cleaned");

	}
	
	element.style.display = 'none';
	document.body.appendChild(element);

	element.click();

	document.body.removeChild(element);
}

function changeFileName() {
// note to self, written long after this function was added: does it work? IDK
	var fs = require('fs');

	fs.rename('mynewfile1.txt', 'myrenamedfile.txt', function (err) {
	  if (err) throw err;
	  console.log('File Renamed!');
	});
}


function hideFileSelectorStuff() {
	var x = document.getElementById("drop_zone");
	x.style.display = "none";
	x = document.getElementById("fileSelectorBox");
	x.style.display = "none";
	x = document.getElementById("processingBox");
	x.style.display = "none";
}

function showMCstuff() {
	var x = document.getElementById("mcBigBox");
	x.style.display = "flex";
}

function showCFstuff() {
	var x = document.getElementById("cfBigBox");
	x.style.display = "block";
}

function inputShowHide() {
	var x = document.getElementById("inputTable");
	var y = document.getElementById("inputShowHide");

	if (y.value == "Hide") {
		x.style.display = "none";
		y.value = "Show";
	} else {
		x.style.display = "block";
		y.value = "Hide";
	}		
}

function outputShowHide() {
	var x = document.getElementById("outputTable");
	var y = document.getElementById("outputShowHide");
	
	if (y.value == "Hide") {
		x.style.display = "none";
		y.value = "Show";
	} else {
		x.style.display = "block";
		y.value = "Hide";
	}		
}

function showHide(elementName) {
	var x = document.getElementById(elementName);
	
	if (x.style.display == "none") {
		x.style.display = "block";
	} else {
		x.style.display = "none";
	}
}

function sortTable(n,tableName) {
// 		document.body.style.cursor = 'progress'; //  make this work. Or make a thinker element instead


  var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
  table = document.getElementById(tableName);
  switching = true;
  // Set the sorting direction to ascending:
  dir = "asc"; 
  /* Make a loop that will continue until no switching has been done: */
  while (switching) {
	// Start by saying: no switching is done:
	switching = false;
	rows = table.getElementsByTagName("TR");
	/* Loop through all table rows (except the first, which contains table headers): */
	for (i = 1; i < (rows.length - 1); i++) {
	  // Start by saying there should be no switching:
	  shouldSwitch = false;
	  /* Get the two elements you want to compare, one from current row and one from the next: */
	  x = rows[i].getElementsByTagName("TD")[n];
	  y = rows[i + 1].getElementsByTagName("TD")[n];
	  x = x.innerHTML.toLowerCase();
	  y = y.innerHTML.toLowerCase();
	  
	  if (isNaN(x) == false && isNaN(y) == false && x.trim() != "" && y.trim != "") {
		// if they're both numbers convert to numerical sort. Nate added this. 
		// note that this isn't perfect; number will convert the following to numbers: true, false, " ", "", and probably others. 
		x = Number(x);
		y = Number(y);
	  }

	  /* Check if the two rows should switch place, based on the direction, asc or desc: */
	  if (dir == "asc") {
		if (x > y) {
		  // If so, mark as a switch and break the loop:
		  shouldSwitch = true;
		  break;
		}
	  } else if (dir == "desc") {
		if (x < y) {
		  // If so, mark as a switch and break the loop:
		  shouldSwitch = true;
		  break;
		}
	  }
	}
	if (shouldSwitch) {
	  /* If a switch has been marked, make the switch
	  and mark that a switch has been done: */
	  rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
	  switching = true;
	  // Each time a switch is done, increase this count by 1:
	  switchcount ++; 
	} else {
	  /* If no switching has been done AND the direction is "asc",
	  set the direction to "desc" and run the while loop again. */
	  if (switchcount == 0 && dir == "asc") {
		dir = "desc";
		switching = true;
	  }
	}
  }
// document.body.style.cursor = 'auto';

}



// 	 /* When the user clicks on the dropdown button, 
// 	toggle between hiding and showing the dropdown content */
// 	function showDropdown() {
// 		document.getElementById("myDropdown").classList.toggle("show");
// 	}
// 
// 	// Close the dropdown if the user clicks outside of it
// 	window.onclick = function(event) {
// 		if (!event.target.matches('.dropbtn')) {
// 
// 			var dropdowns = document.getElementsByClassName("dropdown-content");
// 			var i;
// 			for (i = 0; i < dropdowns.length; i++) {
// 				var openDropdown = dropdowns[i];
// 				if (openDropdown.classList.contains('show')) {
// 					openDropdown.classList.remove('show');
// 				}
// 			}
// 		}
// 	}