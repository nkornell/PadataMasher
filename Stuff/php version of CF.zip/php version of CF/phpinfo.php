<?php
   phpinfo();
?>